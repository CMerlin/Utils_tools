#include <iostream>
#include <vector>

//4sum问题：数组中找到4个数和为target
//将问题分为：
//1)two sum
//2)k sum 化为 k-1 sum问题
using namespace std;

void ksum(vector<int>& nums, int target , vector<vector<int>>& res, int start, int k){
    if(k==0&&target==0)return;
}
int main(){
    
    return 0;
}
