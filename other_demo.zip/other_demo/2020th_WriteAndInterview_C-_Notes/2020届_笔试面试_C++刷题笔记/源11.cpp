//#include <iostream>
//using namespace std;
//
//int function(int a)
//{
//	if (a == 1 || a == 0)
//	{
//		return 1;
//	}
//	if (a < 1)
//	{
//		return 0;
//	}
//	if (a == 2)
//	{
//		return 2;
//	}
//	return function(a - 1) + function(a - 2) + function(a - 3);
//}
//
//int main(void)
//{
//	int n = 0;
//	while (cin >> n)
//	{
//		cout << function(n) << endl;
//	}
//	return 0;
//}