#pragma once

template<class T>
void BubbleSort(T * array, const int len);
