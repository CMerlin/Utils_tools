#pragma once

template<class T>
void SelectSort(T *array, const int len);
