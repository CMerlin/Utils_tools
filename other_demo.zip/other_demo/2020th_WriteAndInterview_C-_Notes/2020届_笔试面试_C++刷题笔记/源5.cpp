//#include <iostream>
//#include <string>
//#include <algorithm>
//#include <vector>
//using namespace std;
//
//static int Min(int x, int y)
//{
//	return x < y ? x : y;
//}
//
//static void function(string s1, string s2)
//{
//	for (auto it : s2)
//	{
//		if (count(s1.begin(), s1.end(), it) != 0)
//		{
//			continue;
//		}
//		else
//		{
//			cout << "{" << "\n" << "}" << endl;
//			return;
//		}
//	}
//
//	// ��ʵ��
//	vector<char> result;
//	int pos = s1.find(s2);
//
//}
//
//int main(void)
//{
//	string s1 = "123";
//	string s2 = "3";
//	function(s1, s2);
//
//	return 0;
//}