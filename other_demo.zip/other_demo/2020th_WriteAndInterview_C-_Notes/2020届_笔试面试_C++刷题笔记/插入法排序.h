#pragma once

template<class T>
void InsertSort(T * array, const int len);

