#pragma once

template<class T>
void ShellSort(T *array, int len);

