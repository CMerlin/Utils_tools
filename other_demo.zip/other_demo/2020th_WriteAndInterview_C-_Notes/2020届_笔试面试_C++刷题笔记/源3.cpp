//#include <iostream>
// 
//#include <vector>
//#include <algorithm>
//using namespace std;
//
//bool compare(int a, int b)
//{
//	return a > b;
//}
//
//int main(void)
//{
//	int n, m, k;
//	while (cin >> n >> m >> k)
//	{
//		vector<unsigned short> arr;
//		for (int i = 0; i < n; ++i) 
//		{
//			for (int j = 0; j < m; ++j)
//			{
//				arr.push_back((i + 1)*(j + 1));
//			}
//		}
//		sort(arr.begin(), arr.end(), compare);
//		cout << arr[k - 1] << endl;
//	}
//	return 0;
//}