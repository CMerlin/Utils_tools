#pragma once
template<class T>
void MergeSort(T *array, int len);

