#pragma once

template<class T>
void Quicksort(T *array, int low, int high);



